public class PCTest {
    public static void main (String[] args) {
        PC manipulator = new PC();

        String mypitch = manipulator.elevatorPitch("Stephen", "peep my mixtape"); 
        System.out.println(mypitch);

        new PC();
        new PC("Its me bruv");
        new PC("Fockin Wanka", "Ye wanna av a go?");
        // System.out.println(a);
        // System.out.println(b);
        // System.out.println(c);



    }
}