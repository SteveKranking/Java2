public class ALTest {
    public static void main(String[] args) {
    AL manipulator = new AL();
    // manipulator.firstFor();

    // manipulator.forOdds();

    // manipulator.sums();

    // int[] x = {1,3,5,7,9,13};
    // manipulator.thruArray(x);

    // manipulator.findMax(x);

    // manipulator.findAvg(x);

    manipulator.arrayOdds();
}
}