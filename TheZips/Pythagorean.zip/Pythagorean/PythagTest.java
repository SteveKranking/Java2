public class PythagTest {
    public static void main(String[] args) {
        Pythag hyp = new Pythag();
        Double result = hyp.calculateHypotenuse(3, 4);
        System.out.println(result);
   }
}