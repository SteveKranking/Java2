public class FizzTest {
    public static void main(String[] args) {
        Fizz output = new Fizz();
        output.fizzBuzz(2);
   }
}