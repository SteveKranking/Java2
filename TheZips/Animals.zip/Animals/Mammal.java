class Mammal{
    private int energy = 100;

    public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	} 
}