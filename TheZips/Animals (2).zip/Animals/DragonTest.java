public class DragonTest{
    public static void main(String[] args) {
        Dragon drago = new Dragon();
        drago.attackTown();
        drago.attackTown();
        drago.attackTown();
        drago.eatHumans();
        drago.eatHumans();
        drago.fly();
        drago.fly();
    }
}