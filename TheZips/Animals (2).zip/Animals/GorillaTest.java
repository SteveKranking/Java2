public class GorillaTest{
    public static void main(String[] args) {
        Gorilla gym = new Gorilla();
        gym.throwing();
        gym.eatBanana();
        gym.climb();
    }
}